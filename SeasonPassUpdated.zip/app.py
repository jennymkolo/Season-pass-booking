from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bookings.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    date = db.Column(db.String(50), nullable=False)
    service = db.Column(db.String(50), nullable=False)
    notes = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def home():
    return "Season Pass Booking API Running"

@app.route('/book', methods=['POST'])
def book():
    data = request.get_json()
    if not all(k in data for k in ('name', 'email', 'date', 'service')):
        return jsonify({'error': 'Missing required fields'}), 400
    try:
        new_booking = Booking(
            name=data['name'],
            email=data['email'],
            date=data['date'],
            service=data['service'],
            notes=data.get('notes', '')
        )
        db.session.add(new_booking)
        db.session.commit()
        return jsonify({'message': 'Booking saved successfully!'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
